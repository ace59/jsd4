// Elements
// ------------------------------------------




// Update page
// ------------------------------------------

console.log("99 bottles of beer on the wall!");